# Skip the Line on Flask

Clone the repo and install Python 3 and pip (just google how to do so). Then run in the command line 
```shell script
pip install -r requirements.txt
# or
pip3 install -r requirements.txt
```

Here is the link to the login tutorial if anybody still needs it:
https://www.youtube.com/watch?v=CSHx6eCkmv0

Postgres SQL found at postgresql-lively-10874.